package com.example.projetodesoftwaretrabalho1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetodeSoftwareTrabalho1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
