package com.example.projetodesoftwaretrabalho1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetodeSoftwareTrabalho1Application {

    public static void main(String[] args) {
        SpringApplication.run(ProjetodeSoftwareTrabalho1Application.class, args);
    }

}
